package com.smartgallery.app.ui

import android.app.Application
import android.content.IntentSender
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smartgallery.app.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GalleryViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = MediaRepository(app)
    private val store = DeletionStore(app)
    private val settings = AppSettings(app)
    private val classifier: ExplicitMediaClassifier = UnavailableClassifier()

    var media by mutableStateOf<List<MediaItem>>(emptyList()); private set
    var box by mutableStateOf<List<BoxEntry>>(emptyList()); private set
    var review by mutableStateOf<List<ReviewEntry>>(emptyList()); private set
    var explicitAutoDelete by mutableStateOf(settings.explicitAutoDelete); private set
    var trustHighConfidence by mutableStateOf(settings.trustHighConfidence); private set
    var message by mutableStateOf<String?>(null)
    val detectionAvailable: Boolean get() = classifier.isAvailable

    private var pendingDeleteIds: List<Long> = emptyList()

    fun refresh() {
        viewModelScope.launch {
            val (all, boxed, rev) = withContext(Dispatchers.IO) {
                Triple(repo.loadAll(), store.boxAll(), store.reviewAll())
            }
            val hidden = boxed.map { it.mediaId }.toSet()
            media = all.filter { it.id !in hidden }
            box = boxed
            review = rev
        }
    }

    /** Ordinary delete: moves to the in-app box for 7 days. The file itself is untouched. */
    fun moveToBox(items: List<MediaItem>) {
        viewModelScope.launch(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            items.forEach {
                store.putBox(
                    BoxEntry(it.id, it.uri.toString(), it.displayName, it.kind,
                        DeletionReason.ORDINARY, ConfirmationSource.USER, now,
                        DeletionPolicy.expiresAt(DeletionReason.ORDINARY, now))
                )
            }
            refresh()
        }
    }

    fun restore(ids: Collection<Long>) {
        viewModelScope.launch(Dispatchers.IO) { store.removeBox(ids); refresh() }
    }

    /** Human confirmed a flagged item is explicit. Only now does it enter the 24h queue. */
    fun confirmExplicit(e: ReviewEntry) {
        viewModelScope.launch(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            store.putBox(
                BoxEntry(e.mediaId, e.uri, e.displayName, e.kind,
                    DeletionReason.EXPLICIT_CONFIRMED, ConfirmationSource.USER, now,
                    DeletionPolicy.expiresAt(DeletionReason.EXPLICIT_CONFIRMED, now))
            )
            store.removeReview(e.mediaId)
            refresh()
        }
    }

    fun dismissReview(e: ReviewEntry) {
        viewModelScope.launch(Dispatchers.IO) { store.removeReview(e.mediaId); refresh() }
    }

    /** Scans with the classifier if one exists. Uncertain results go to review only. */
    fun scan() {
        if (!classifier.isAvailable) {
            message = "No on-device detection model is installed, so nothing was scanned."
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            val policy = settings.policy()
            for (item in media) {
                val s = classifier.score(item) ?: continue
                when (DeletionPolicy.triage(s)) {
                    DeletionPolicy.Triage.IGNORE -> Unit
                    DeletionPolicy.Triage.REVIEW -> store.putReview(
                        ReviewEntry(item.id, item.uri.toString(), item.displayName, item.kind, s, now))
                    DeletionPolicy.Triage.HIGH_CONFIDENCE ->
                        if (DeletionPolicy.mayAutoQueueHighConfidence(s, policy)) store.putBox(
                            BoxEntry(item.id, item.uri.toString(), item.displayName, item.kind,
                                DeletionReason.EXPLICIT_CONFIRMED, ConfirmationSource.AI_HIGH_CONFIDENCE, now,
                                DeletionPolicy.expiresAt(DeletionReason.EXPLICIT_CONFIRMED, now)))
                        else store.putReview(
                            ReviewEntry(item.id, item.uri.toString(), item.displayName, item.kind, s, now))
                }
            }
            refresh()
        }
    }

    fun setExplicitAutoDelete(v: Boolean) { settings.explicitAutoDelete = v; explicitAutoDelete = v }
    fun setTrustHighConfidence(v: Boolean) { settings.trustHighConfidence = v; trustHighConfidence = v }

    fun dueEntries(now: Long = System.currentTimeMillis()): List<BoxEntry> =
        box.filter { DeletionPolicy.mayPermanentlyDelete(it, now, settings.policy()) }

    /** System delete-confirmation (Android 11+). Caller launches the returned IntentSender. */
    fun requestDelete(ids: List<Long>): IntentSender? {
        if (ids.isEmpty()) return null
        pendingDeleteIds = ids
        val uris: List<Uri> = box.filter { it.mediaId in ids }.map { Uri.parse(it.uri) }
        return MediaStore.createDeleteRequest(getApplication<Application>().contentResolver, uris).intentSender
    }

    fun onDeleteResult(ok: Boolean) {
        if (ok) {
            viewModelScope.launch(Dispatchers.IO) { store.removeBox(pendingDeleteIds); refresh() }
            message = "Deleted permanently."
        } else message = "Deletion cancelled. Nothing was deleted."
        pendingDeleteIds = emptyList()
    }
}
