package com.smartgallery.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import com.smartgallery.app.ui.SmartGalleryRoot

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // No PIN, password, biometric lock or login: the app opens straight to the gallery.
        setContent { MaterialTheme { SmartGalleryRoot() } }
    }
}
