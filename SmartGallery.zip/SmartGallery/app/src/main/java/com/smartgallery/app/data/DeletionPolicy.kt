package com.smartgallery.app.data

data class PolicySettings(
    /** User toggle: delete user-confirmed explicit media 24h after queuing. Default OFF. */
    val explicitAutoDelete: Boolean = false,
    /** User toggle: treat very-high-confidence AI detections as confirmed. Default OFF. */
    val trustHighConfidence: Boolean = false,
)

/** Pure logic (no Android types) so it can be unit-tested on the JVM. */
object DeletionPolicy {
    const val ORDINARY_RETENTION_MS = 7L * 24 * 60 * 60 * 1000
    const val EXPLICIT_DELAY_MS = 24L * 60 * 60 * 1000
    const val REVIEW_THRESHOLD = 0.50f
    const val HIGH_CONFIDENCE = 0.95f

    enum class Triage { IGNORE, REVIEW, HIGH_CONFIDENCE }

    fun triage(score: Float): Triage = when {
        score >= HIGH_CONFIDENCE -> Triage.HIGH_CONFIDENCE
        score >= REVIEW_THRESHOLD -> Triage.REVIEW
        else -> Triage.IGNORE
    }

    fun expiresAt(reason: DeletionReason, queuedAt: Long): Long = queuedAt + when (reason) {
        DeletionReason.ORDINARY -> ORDINARY_RETENTION_MS
        DeletionReason.EXPLICIT_CONFIRMED -> EXPLICIT_DELAY_MS
    }

    /** Whether a high-confidence detection may enter the box without a human decision. */
    fun mayAutoQueueHighConfidence(score: Float, s: PolicySettings): Boolean =
        s.trustHighConfidence && s.explicitAutoDelete && triage(score) == Triage.HIGH_CONFIDENCE

    /** The single gate for permanent deletion. */
    fun mayPermanentlyDelete(e: BoxEntry, now: Long, s: PolicySettings): Boolean {
        if (now < e.expiresAt) return false
        return when (e.reason) {
            DeletionReason.ORDINARY -> true // the user chose to delete it; 7 days have passed
            DeletionReason.EXPLICIT_CONFIRMED -> when (e.source) {
                ConfirmationSource.USER -> s.explicitAutoDelete
                ConfirmationSource.AI_HIGH_CONFIDENCE -> s.explicitAutoDelete && s.trustHighConfidence
            }
        }
    }
}
