package com.smartgallery.app.work

import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.smartgallery.app.data.AppSettings
import com.smartgallery.app.data.DeletionPolicy
import com.smartgallery.app.data.DeletionStore

/**
 * Hourly check. A background worker cannot show Android's delete-confirmation dialog, so it only
 * deletes when the user has granted the optional "Media management" special access.
 * Otherwise due items stay in the box and the UI asks for one-tap confirmation.
 */
class ExpiryWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            !MediaStore.canManageMedia(applicationContext)
        ) return Result.success()

        val store = DeletionStore(applicationContext)
        val policy = AppSettings(applicationContext).policy()
        val now = System.currentTimeMillis()
        val due = store.boxAll().filter { DeletionPolicy.mayPermanentlyDelete(it, now, policy) }
        val finished = due.filter {
            try {
                applicationContext.contentResolver.delete(Uri.parse(it.uri), null, null)
                true // deleted, or already gone
            } catch (e: SecurityException) {
                false
            }
        }.map { it.mediaId }
        store.removeBox(finished)
        return Result.success()
    }
}
