package com.smartgallery.app.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.smartgallery.app.data.*

private fun requiredPermissions(): Array<String> = when {
    Build.VERSION.SDK_INT >= 34 -> arrayOf(
        Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO,
        Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
    Build.VERSION.SDK_INT >= 33 -> arrayOf(
        Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
    else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
}

private fun hasAccess(ctx: Context): Boolean {
    fun g(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    return when {
        Build.VERSION.SDK_INT >= 34 -> (g(Manifest.permission.READ_MEDIA_IMAGES) ||
            g(Manifest.permission.READ_MEDIA_VIDEO) ||
            g(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED))
        Build.VERSION.SDK_INT >= 33 -> g(Manifest.permission.READ_MEDIA_IMAGES) ||
            g(Manifest.permission.READ_MEDIA_VIDEO)
        else -> g(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
}

@Composable
fun SmartGalleryRoot(vm: GalleryViewModel = viewModel()) {
    val ctx = LocalContext.current
    var access by remember { mutableStateOf(hasAccess(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { access = hasAccess(ctx) }
    LaunchedEffect(access) { if (access) vm.refresh() }

    if (!access) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("SmartGallery needs access to your photos and videos", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text("Media is read on your device only. Nothing is uploaded.")
            Spacer(Modifier.height(16.dp))
            Button(onClick = { permLauncher.launch(requiredPermissions()) }) { Text("Grant access") }
        }
        return
    }

    val deleteLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { vm.onDeleteResult(it.resultCode == Activity.RESULT_OK) }
    fun launchDelete(ids: List<Long>) {
        vm.requestDelete(ids)?.let { deleteLauncher.launch(IntentSenderRequest.Builder(it).build()) }
    }

    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) { vm.message?.let { snackbar.showSnackbar(it); vm.message = null } }

    var tab by remember { mutableIntStateOf(0) }
    val labels = listOf("Gallery", "Review (${vm.review.size})", "Deletion box (${vm.box.size})", "Settings")
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            NavigationBar {
                labels.forEachIndexed { i, l ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = {}, label = { Text(l, maxLines = 1) }, alwaysShowLabel = true)
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> GalleryTab(vm)
                1 -> ReviewTab(vm)
                2 -> BoxTab(vm, ::launchDelete)
                else -> SettingsTab(vm)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun GalleryTab(vm: GalleryViewModel) {
    var selected by remember { mutableStateOf(setOf<Long>()) }
    Column(Modifier.fillMaxSize()) {
        if (selected.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${selected.size} selected", Modifier.weight(1f))
                TextButton(onClick = { selected = emptySet() }) { Text("Clear") }
                Button(onClick = {
                    vm.moveToBox(vm.media.filter { it.id in selected }); selected = emptySet()
                }) { Text("Move to deletion box") }
            }
        }
        if (vm.media.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No photos or videos found") }
        } else LazyVerticalGrid(columns = GridCells.Adaptive(110.dp), contentPadding = PaddingValues(2.dp)) {
            gridItems(vm.media, key = { it.id }) { m ->
                val isSel = m.id in selected
                Box(
                    Modifier.padding(2.dp).aspectRatio(1f)
                        .then(if (isSel) Modifier.border(3.dp, MaterialTheme.colorScheme.primary) else Modifier)
                        .combinedClickable(
                            onClick = { if (selected.isNotEmpty()) selected = if (isSel) selected - m.id else selected + m.id },
                            onLongClick = { selected = selected + m.id },
                        )
                ) {
                    AsyncImage(m.uri, m.displayName, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    if (m.kind == MediaKind.VIDEO) {
                        Text(formatDuration(m.durationMs),
                            Modifier.align(Alignment.BottomEnd).background(MaterialTheme.colorScheme.scrim).padding(horizontal = 4.dp),
                            color = MaterialTheme.colorScheme.surface, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun ReviewTab(vm: GalleryViewModel) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Manual review", style = MaterialTheme.typography.titleLarge)
            Text("Items the detector was unsure about land here. Nothing in this list is ever deleted automatically; only you can move an item to the deletion box.")
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { vm.scan() }) { Text("Scan library") }
            if (!vm.detectionAvailable) Text("Detection is off: no on-device model is installed in this build.", color = MaterialTheme.colorScheme.error)
        }
        if (vm.review.isEmpty()) item { Text("Nothing to review.") }
        items(vm.review, key = { it.mediaId }) { e ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(Uri.parse(e.uri), e.displayName, Modifier.size(96.dp).clip(MaterialTheme.shapes.small), contentScale = ContentScale.Crop)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(e.displayName, maxLines = 1)
                    Text("Model confidence ${(e.score * 100).toInt()}% (uncertain)", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { vm.confirmExplicit(e) }) { Text("Explicit") }
                        OutlinedButton(onClick = { vm.dismissReview(e) }) { Text("Keep") }
                    }
                }
            }
        }
    }
}

@Composable
private fun BoxTab(vm: GalleryViewModel, launchDelete: (List<Long>) -> Unit) {
    val due = vm.dueEntries()
    val now = System.currentTimeMillis()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Deletion box", style = MaterialTheme.typography.titleLarge)
            Text("Ordinary deletions can be restored for 7 days. Confirmed explicit media is deleted 24 hours after queuing, only if you enable that in Settings. Files are not touched until the final delete, and Android asks you to confirm it.")
            if (due.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Button(onClick = { launchDelete(due.map { it.mediaId }) }) { Text("Confirm deletion of ${due.size} due item(s)") }
            }
        }
        if (vm.box.isEmpty()) item { Text("The box is empty.") }
        items(vm.box, key = { it.mediaId }) { e ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(Uri.parse(e.uri), e.displayName, Modifier.size(80.dp).clip(MaterialTheme.shapes.small), contentScale = ContentScale.Crop)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(e.displayName, maxLines = 1)
                    val why = if (e.reason == DeletionReason.ORDINARY) "Deleted by you" else
                        if (e.source == ConfirmationSource.USER) "Explicit (confirmed by you)" else "Explicit (high-confidence AI, opted in)"
                    Text(why, style = MaterialTheme.typography.bodySmall)
                    val left = e.expiresAt - now
                    Text(
                        when {
                            e.reason == DeletionReason.EXPLICIT_CONFIRMED && !vm.explicitAutoDelete -> "Auto-delete is off; kept until you act"
                            left > 0 -> "Final deletion in ${formatRemaining(left)}"
                            else -> "Due for deletion"
                        }, style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { vm.restore(listOf(e.mediaId)) }) { Text("Restore") }
                        TextButton(onClick = { launchDelete(listOf(e.mediaId)) }) { Text("Delete now") }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsTab(vm: GalleryViewModel) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Settings", style = MaterialTheme.typography.titleLarge)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Delete confirmed explicit media after 24 hours")
                Text("Off by default. Applies only to items you confirmed.", style = MaterialTheme.typography.bodySmall)
            }
            Switch(vm.explicitAutoDelete, vm::setExplicitAutoDelete)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Treat very-high-confidence detections as confirmed")
                Text("Off by default. Requires the switch above. Uncertain detections are never auto-deleted either way.", style = MaterialTheme.typography.bodySmall)
            }
            Switch(vm.trustHighConfidence, vm::setTrustHighConfidence, enabled = vm.explicitAutoDelete)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_REQUEST_MANAGE_MEDIA, Uri.parse("package:${ctx.packageName}")))
            }) { Text("Allow deletions without a prompt (optional)") }
        }
    }
}

private fun formatDuration(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

private fun formatRemaining(ms: Long): String {
    val h = ms / 3_600_000
    return if (h >= 48) "${h / 24} days" else if (h >= 1) "$h h" else "${ms / 60_000} min"
}
