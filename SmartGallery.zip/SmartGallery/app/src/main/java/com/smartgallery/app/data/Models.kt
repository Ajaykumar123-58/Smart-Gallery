package com.smartgallery.app.data

import android.net.Uri

enum class MediaKind { IMAGE, VIDEO }

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val kind: MediaKind,
    val displayName: String,
    val dateAddedSec: Long,
    val durationMs: Long,
)

/** Why an item is in the deletion box. There is deliberately NO "uncertain" reason. */
enum class DeletionReason { ORDINARY, EXPLICIT_CONFIRMED }

/** Who confirmed the item. AI_HIGH_CONFIDENCE only exists if the user opted in. */
enum class ConfirmationSource { USER, AI_HIGH_CONFIDENCE }

data class BoxEntry(
    val mediaId: Long,
    val uri: String,
    val displayName: String,
    val kind: MediaKind,
    val reason: DeletionReason,
    val source: ConfirmationSource,
    val queuedAt: Long,
    val expiresAt: Long,
)

/** An uncertain detection awaiting a human decision. Never auto-deleted. */
data class ReviewEntry(
    val mediaId: Long,
    val uri: String,
    val displayName: String,
    val kind: MediaKind,
    val score: Float,
    val flaggedAt: Long,
)
