package com.smartgallery.app.data

/**
 * Hook for an on-device explicit-content model.
 * Returns a score in 0..1, or null when no model is available.
 * NOTE: no model is bundled in this project, so detection is OFF until one is supplied.
 */
interface ExplicitMediaClassifier {
    val isAvailable: Boolean
    suspend fun score(item: MediaItem): Float?
}

class UnavailableClassifier : ExplicitMediaClassifier {
    override val isAvailable = false
    override suspend fun score(item: MediaItem): Float? = null
}
