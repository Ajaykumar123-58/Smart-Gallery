package com.smartgallery.app.data

import android.content.Context

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("smartgallery_settings", Context.MODE_PRIVATE)

    var explicitAutoDelete: Boolean
        get() = prefs.getBoolean("explicit_auto_delete", false)
        set(v) = prefs.edit().putBoolean("explicit_auto_delete", v).apply()

    var trustHighConfidence: Boolean
        get() = prefs.getBoolean("trust_high_confidence", false)
        set(v) = prefs.edit().putBoolean("trust_high_confidence", v).apply()

    fun policy() = PolicySettings(explicitAutoDelete, trustHighConfidence)
}
