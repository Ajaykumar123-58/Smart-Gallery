package com.smartgallery.app.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DeletionStore(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "smartgallery.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE deletion_box(media_id INTEGER PRIMARY KEY, uri TEXT NOT NULL, " +
                "display_name TEXT NOT NULL, kind TEXT NOT NULL, reason TEXT NOT NULL, " +
                "source TEXT NOT NULL, queued_at INTEGER NOT NULL, expires_at INTEGER NOT NULL)"
        )
        db.execSQL(
            "CREATE TABLE review_queue(media_id INTEGER PRIMARY KEY, uri TEXT NOT NULL, " +
                "display_name TEXT NOT NULL, kind TEXT NOT NULL, score REAL NOT NULL, " +
                "flagged_at INTEGER NOT NULL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    // ---- deletion box ----
    fun putBox(e: BoxEntry) {
        val v = ContentValues().apply {
            put("media_id", e.mediaId); put("uri", e.uri); put("display_name", e.displayName)
            put("kind", e.kind.name); put("reason", e.reason.name); put("source", e.source.name)
            put("queued_at", e.queuedAt); put("expires_at", e.expiresAt)
        }
        writableDatabase.insertWithOnConflict("deletion_box", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun boxAll(): List<BoxEntry> =
        readableDatabase.query("deletion_box", null, null, null, null, null, "expires_at ASC").use { c ->
            buildList { while (c.moveToNext()) add(c.toBox()) }
        }

    fun removeBox(ids: Collection<Long>) = ids.forEach {
        writableDatabase.delete("deletion_box", "media_id=?", arrayOf(it.toString()))
    }

    // ---- review queue (uncertain detections) ----
    fun putReview(e: ReviewEntry) {
        val v = ContentValues().apply {
            put("media_id", e.mediaId); put("uri", e.uri); put("display_name", e.displayName)
            put("kind", e.kind.name); put("score", e.score); put("flagged_at", e.flaggedAt)
        }
        writableDatabase.insertWithOnConflict("review_queue", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun reviewAll(): List<ReviewEntry> =
        readableDatabase.query("review_queue", null, null, null, null, null, "score DESC").use { c ->
            buildList { while (c.moveToNext()) add(c.toReview()) }
        }

    fun removeReview(id: Long) {
        writableDatabase.delete("review_queue", "media_id=?", arrayOf(id.toString()))
    }

    private fun Cursor.toBox() = BoxEntry(
        mediaId = getLong(getColumnIndexOrThrow("media_id")),
        uri = getString(getColumnIndexOrThrow("uri")),
        displayName = getString(getColumnIndexOrThrow("display_name")),
        kind = MediaKind.valueOf(getString(getColumnIndexOrThrow("kind"))),
        reason = DeletionReason.valueOf(getString(getColumnIndexOrThrow("reason"))),
        source = ConfirmationSource.valueOf(getString(getColumnIndexOrThrow("source"))),
        queuedAt = getLong(getColumnIndexOrThrow("queued_at")),
        expiresAt = getLong(getColumnIndexOrThrow("expires_at")),
    )

    private fun Cursor.toReview() = ReviewEntry(
        mediaId = getLong(getColumnIndexOrThrow("media_id")),
        uri = getString(getColumnIndexOrThrow("uri")),
        displayName = getString(getColumnIndexOrThrow("display_name")),
        kind = MediaKind.valueOf(getString(getColumnIndexOrThrow("kind"))),
        score = getFloat(getColumnIndexOrThrow("score")),
        flaggedAt = getLong(getColumnIndexOrThrow("flagged_at")),
    )
}
