package com.smartgallery.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DeletionPolicyTest {
    private fun entry(reason: DeletionReason, src: ConfirmationSource, queuedAt: Long = 0L) = BoxEntry(
        1, "content://x/1", "a.jpg", MediaKind.IMAGE, reason, src, queuedAt,
        DeletionPolicy.expiresAt(reason, queuedAt))

    @Test fun ordinaryKept7Days() {
        val e = entry(DeletionReason.ORDINARY, ConfirmationSource.USER)
        assertFalse(DeletionPolicy.mayPermanentlyDelete(e, DeletionPolicy.ORDINARY_RETENTION_MS - 1, PolicySettings()))
        assertTrue(DeletionPolicy.mayPermanentlyDelete(e, DeletionPolicy.ORDINARY_RETENTION_MS, PolicySettings()))
    }

    @Test fun explicitNeverDeletedWhenToggleOff() {
        val e = entry(DeletionReason.EXPLICIT_CONFIRMED, ConfirmationSource.USER)
        assertFalse(DeletionPolicy.mayPermanentlyDelete(e, Long.MAX_VALUE, PolicySettings(explicitAutoDelete = false)))
    }

    @Test fun explicitDeletedAfter24hWhenEnabled() {
        val e = entry(DeletionReason.EXPLICIT_CONFIRMED, ConfirmationSource.USER)
        val s = PolicySettings(explicitAutoDelete = true)
        assertFalse(DeletionPolicy.mayPermanentlyDelete(e, DeletionPolicy.EXPLICIT_DELAY_MS - 1, s))
        assertTrue(DeletionPolicy.mayPermanentlyDelete(e, DeletionPolicy.EXPLICIT_DELAY_MS, s))
    }

    @Test fun aiHighConfidenceNeedsExtraOptIn() {
        val e = entry(DeletionReason.EXPLICIT_CONFIRMED, ConfirmationSource.AI_HIGH_CONFIDENCE)
        assertFalse(DeletionPolicy.mayPermanentlyDelete(e, Long.MAX_VALUE, PolicySettings(explicitAutoDelete = true)))
        assertTrue(DeletionPolicy.mayPermanentlyDelete(e, Long.MAX_VALUE, PolicySettings(true, true)))
    }

    @Test fun uncertainScoresNeverAutoQueue() {
        val s = PolicySettings(true, true)
        assertEquals(DeletionPolicy.Triage.REVIEW, DeletionPolicy.triage(0.80f))
        assertFalse(DeletionPolicy.mayAutoQueueHighConfidence(0.80f, s))
        assertEquals(DeletionPolicy.Triage.IGNORE, DeletionPolicy.triage(0.10f))
        assertTrue(DeletionPolicy.mayAutoQueueHighConfidence(0.97f, s))
    }
}
