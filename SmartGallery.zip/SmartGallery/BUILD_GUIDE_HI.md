# SmartGallery — Build Guide (Hindi)

## Project
- Package ID: `com.smartgallery.app`
- Kotlin + Jetpack Compose
- Minimum Android: 11 (API 30)
- यह source ZIP है; verified APK इसमें शामिल नहीं है।

## Android Studio में खोलें
1. ZIP extract करें।
2. Android Studio में `SmartGallery` नाम वाला folder खोलें—यही वह folder है जिसमें `settings.gradle.kts` है।
3. JDK 17 और Android SDK Platform 34 उपलब्ध रखें।
4. Gradle Sync पूरा होने दें।
5. `Build > Make Project` चलाएँ।
6. Tests के लिए `:app:testDebugUnitTest` और APK के लिए `:app:assembleDebug` चलाएँ।
7. Build सफल होने पर APK `app/build/outputs/apk/debug/app-debug.apk` में मिलेगी।

## ज़रूरी सीमा
इस ZIP में AI detection model नहीं है। इसलिए AI scan अभी चालू नहीं है। `ExplicitMediaClassifier` में वास्तविक on-device model जोड़ने और device पर परीक्षण करने के बाद ही detection को working मानें। इस environment में Android SDK/Gradle उपलब्ध नहीं थे, इसलिए build success की पुष्टि नहीं की गई है।
