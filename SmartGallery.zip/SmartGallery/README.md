# SmartGallery — Android source project

**Package:** `com.smartgallery.app`  
**Language/UI:** Kotlin + Jetpack Compose  
**Minimum Android:** Android 11 (API 30)  
**Status:** Source project prepared; build has NOT been verified in this environment. No APK is included.

## What is implemented

- MediaStore-based photo/video gallery with multi-select.
- In-app deletion box. Moving an item to the box does not delete the original file.
- Restore from the deletion box.
- Ordinary items become eligible for permanent deletion after 7 days.
- Explicit-media items have a 24-hour delay, and the setting is OFF by default.
- Uncertain model results are intended for manual review only.
- Android's system confirmation is used for permanent deletion when required.
- Optional Media Management access is requested through Settings; it is not silently granted.

## Important limitations

- **No AI model is bundled.** `UnavailableClassifier` is deliberately disabled, so scanning reports that detection is unavailable. A compatible on-device model and implementation of `ExplicitMediaClassifier` must be added before AI detection can work.
- This project has not been compiled or tested on an Android device in this environment. Treat this as a source ZIP, not a verified release.
- No login, PIN, password, or biometric app lock is implemented.
- Android may require system confirmation before media can be permanently deleted. Background deletion cannot bypass that restriction.

## Build with Android Studio

1. Install Android Studio (a recent stable release) and JDK 17.
2. Extract this ZIP. Open the `SmartGallery` folder itself (the folder containing `settings.gradle.kts`).
3. Allow Android Studio to sync Gradle and install the Android SDK Platform 34 if prompted.
4. Run **Build > Make Project** and resolve any environment-specific SDK/dependency issues reported by the IDE.
5. Run unit tests from the Gradle tool window, or run `:app:testDebugUnitTest`.
6. Build the debug APK with `:app:assembleDebug`.
7. If successful, the APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

This ZIP does not include a Gradle wrapper. Android Studio can open the project and configure Gradle; if command-line builds are needed, generate/add the wrapper from a working Gradle installation first.

## Safety notes

- AI detection is disabled until a real classifier is supplied.
- Both high-confidence AI queueing and automatic deletion of confirmed explicit items require explicit opt-in and default to OFF.
- Review items are not automatically deleted.
- Test on non-important sample media first and review all Android system deletion prompts carefully.
